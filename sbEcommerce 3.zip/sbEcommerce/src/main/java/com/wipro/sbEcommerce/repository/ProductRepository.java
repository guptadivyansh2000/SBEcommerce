package com.wipro.sbEcommerce.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wipro.sbEcommerce.model.Category;
import com.wipro.sbEcommerce.model.Products;

@Repository
public interface ProductRepository extends JpaRepository<Products, Long>{

	

	Page<Products> findByCategoryOrderByProductPriceAsc(Category category, Pageable pageDetails);

	Page<Products> findByProductNameLikeIgnoreCase(String keyword, Pageable pageDetails);

}
