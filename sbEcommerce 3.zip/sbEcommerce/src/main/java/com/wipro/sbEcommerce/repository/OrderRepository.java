package com.wipro.sbEcommerce.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wipro.sbEcommerce.model.Order;

public interface OrderRepository extends JpaRepository<Order, Long>{

}
