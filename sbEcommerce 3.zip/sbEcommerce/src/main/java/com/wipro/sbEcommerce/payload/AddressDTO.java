package com.wipro.sbEcommerce.payload;

import java.util.ArrayList;
import java.util.List;

import com.wipro.sbEcommerce.model.Users;


public class AddressDTO {

	private Long addressId;
	private String street;
	private String building;
	private String city;
	private String state;
	private String country;
	private String pincode;
	private List<Users> users = new ArrayList<>();
	public AddressDTO() {
		// TODO Auto-generated constructor stub
	}
	public AddressDTO(Long addressId, String street, String building, String city, String state, String country,
			String pincode, List<Users> users) {
		this.addressId = addressId;
		this.street = street;
		this.building = building;
		this.city = city;
		this.state = state;
		this.country = country;
		this.pincode = pincode;
		this.users = users;
	}
	public Long getAddressId() {
		return addressId;
	}
	public void setAddressId(Long addressId) {
		this.addressId = addressId;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getBuilding() {
		return building;
	}
	public void setBuilding(String building) {
		this.building = building;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public List<Users> getUsers() {
		return users;
	}
	public void setUsers(List<Users> users) {
		this.users = users;
	}
	
	
}
