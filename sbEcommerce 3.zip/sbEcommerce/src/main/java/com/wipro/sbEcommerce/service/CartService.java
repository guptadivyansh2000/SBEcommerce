package com.wipro.sbEcommerce.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.wipro.sbEcommerce.payload.CartDTO;

@Service
public interface CartService {

	CartDTO addProductToCart(Long productId, Integer quantity);

	List<CartDTO> getAllCarts();

	CartDTO getCart(String emailId, Long cartId);

	CartDTO updateProductQuantityInCart(Long productId, Integer productQuantity);

	String deleteProductFromCart(Long cartId, Long productId);

	void updateProductInCarts(Long cartId, Long productId);

	
}