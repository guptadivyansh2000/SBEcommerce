package com.wipro.sbEcommerce.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wipro.sbEcommerce.model.Users;

@Repository
public interface UserRepository extends JpaRepository<Users, Long> {

	Optional<Users> findByUserName(String username);

	Boolean existsByUserName(String username);

	Boolean existsByUserEmail(String email);

}
