package com.wipro.sbEcommerce.controller;


import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.sbEcommerce.model.Users;
import com.wipro.sbEcommerce.payload.AddressDTO;
import com.wipro.sbEcommerce.service.AddressServiceImpl;
import com.wipro.sbEcommerce.util.AuthUtil;

import jakarta.validation.Valid;
@RestController
@RequestMapping("/api")
public class AddressController {
	
	private final AuthUtil authUtil;
	private final AddressServiceImpl addressService;
	
	

	public AddressController(AuthUtil authUtil, AddressServiceImpl addressService) {
		this.authUtil = authUtil;
		this.addressService = addressService;
	}



	@PostMapping("/addresses")
	public ResponseEntity<AddressDTO> createAddress(@Valid @RequestBody AddressDTO addressDTO){
		Users user = authUtil.loggedInUser();
		AddressDTO savedAddressDTO = addressService.createAddress(addressDTO, user);
		return new ResponseEntity<AddressDTO>(savedAddressDTO, HttpStatus.CREATED);
	}
	
	@GetMapping("/addresses")
	public ResponseEntity<List<AddressDTO>> getAddresses(){
		List<AddressDTO> addressList = addressService.getAddresses();
		
		return new ResponseEntity<List<AddressDTO>>(addressList,HttpStatus.OK);
	}
	
	@GetMapping("/addresses/{addressId}")
	public ResponseEntity<AddressDTO> getAddressById(@PathVariable Long addressId){
		
		AddressDTO addressDTO = addressService.getAddressById(addressId);
		return new ResponseEntity<AddressDTO>(addressDTO,HttpStatus.OK);
		
	}

}
