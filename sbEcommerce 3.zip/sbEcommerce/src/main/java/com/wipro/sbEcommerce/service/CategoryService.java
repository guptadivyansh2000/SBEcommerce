package com.wipro.sbEcommerce.service;

//import java.util.List;

import com.wipro.sbEcommerce.model.Category;
import com.wipro.sbEcommerce.payload.CategoryDTO;
import com.wipro.sbEcommerce.payload.CategoryResponse;

public interface CategoryService {

	CategoryResponse getAllCategories(Integer PageNumber, Integer PageSize, String sortBy, String sortOrder);

	CategoryDTO createCategory(CategoryDTO categoryDTO);

	CategoryDTO deleteCategory(Long categoryId);

	CategoryDTO updateCategory(CategoryDTO categoryDTO, Long categoryId);
}
