package com.wipro.sbEcommerce.repository;

import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;

import com.wipro.sbEcommerce.model.CartItem;

public interface CartItemRepository extends JpaRepository<CartItem, Long> {
	
	
//	@Query("SELECT ci FROM CartItem ci WHERE ci.cart.id=?1 AND ci.product.id=?2")
	CartItem findCartItemByProducts_ProductIdAndCart_CartId(Long productId, Long cartId);
	
	void deleteByCart_CartIdAndProducts_ProductId(Long cartId, Long productId);

}
