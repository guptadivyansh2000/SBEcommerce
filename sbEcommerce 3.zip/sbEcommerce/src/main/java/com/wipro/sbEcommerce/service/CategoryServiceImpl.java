package com.wipro.sbEcommerce.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.wipro.sbEcommerce.exceptions.APIException;
import com.wipro.sbEcommerce.exceptions.ResourceNotFoundException;
import com.wipro.sbEcommerce.model.Category;
import com.wipro.sbEcommerce.payload.CategoryDTO;
import com.wipro.sbEcommerce.payload.CategoryResponse;
import com.wipro.sbEcommerce.repository.CategoryRepository;

@Service
public class CategoryServiceImpl implements CategoryService {

	@Autowired
	private CategoryRepository categoryRepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	
//	public CategoryServiceImpl(CategoryRepository categoryRepo, ModelMapper modelMapper) {
//		this.categoryRepo = categoryRepo;
//		this.modelMapper = modelMapper;
//	}

	@Override
	public CategoryResponse getAllCategories(Integer pageNumber, Integer pageSize, String sortBy, String sortOrder ) {
		
		Sort sortByAndOrder = sortOrder.equalsIgnoreCase("asc")
				? Sort.by(sortBy).ascending()
				: Sort.by(sortBy).descending();
		Pageable pageDetails = PageRequest.of(pageNumber,pageSize,sortByAndOrder);
		Page<Category> categoryPage = categoryRepo.findAll(pageDetails);
		List<Category> categories = categoryPage.getContent();
		if (categories.isEmpty())
            throw new APIException("No category created till now.");
		List<CategoryDTO> categoryDTOS = categories.stream()
				.map(category->modelMapper.map(category, CategoryDTO.class))
				.toList();
		CategoryResponse categoryResponse  = new CategoryResponse();
		categoryResponse.setContent(categoryDTOS);
		categoryResponse.setPageNumber(categoryPage.getNumber());
		categoryResponse.setPageSize(categoryPage.getSize());
		categoryResponse.setTotalElements(categoryPage.getTotalElements());
		categoryResponse.setTotalPages(categoryPage.getTotalPages());
		categoryResponse.setLastPage(categoryPage.isLast());
		
		return categoryResponse;
	}

	@Override
	public CategoryDTO createCategory(CategoryDTO categoryDTO) {
		// TODO Auto-generated method stub
		Category category  = modelMapper.map(categoryDTO, Category.class);
		Category categoryFromDB = categoryRepo.findByCategoryName(category.getCategoryName());
		if (categoryFromDB != null)
			throw new APIException("Category with the name " + category.getCategoryName() + " already exists !!!");
		Category savedCategory = categoryRepo.save(category);
		
		
		return modelMapper.map(savedCategory,CategoryDTO.class);
	}

	@Override
	public CategoryDTO deleteCategory(Long categoryId) {
		Category category = categoryRepo.findById(categoryId)
				.orElseThrow(() -> new ResourceNotFoundException("Category", "categoryId", categoryId));
		
		categoryRepo.delete(category);
		return modelMapper.map(category, CategoryDTO.class);
	}

	@Override
	public CategoryDTO updateCategory(CategoryDTO categoryDTO, Long categoryId) {
//		Optional<Category> optionalCategory = categories.stream()
//				.filter(c->c.getCategoryId().equals(categoryId))
//				.findFirst();
//		if(optionalCategory.isPresent()) {
//			Category existingCategory = optionalCategory.get();
//			existingCategory.setCategoryName(category.getCategoryName());
//			return existingCategory;
//		}
//		throw new ResponseStatusException(HttpStatus.NOT_FOUND,"category not found");

		Category savedCategory = categoryRepo.findById(categoryId)
				.orElseThrow(() -> new ResourceNotFoundException("Category", "categoryId", categoryId));
		Category updateCatgeory = modelMapper.map(categoryDTO, Category.class);
		updateCatgeory.setCategoryId(categoryId);
		savedCategory = categoryRepo.save(updateCatgeory);
		return modelMapper.map(updateCatgeory, CategoryDTO.class);
	}

}
