package com.wipro.sbEcommerce.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.sbEcommerce.model.Cart;
import com.wipro.sbEcommerce.payload.CartDTO;
import com.wipro.sbEcommerce.repository.CartRepository;
//import com.wipro.sbEcommerce.service.CartService;
import com.wipro.sbEcommerce.service.CartServiceImpl;
import com.wipro.sbEcommerce.util.AuthUtil;

@RestController
@RequestMapping("/api")
public class CartController {
	
	private final CartServiceImpl cartService;
	private final AuthUtil authUtil;
	private final CartRepository cartRepo;
	
	public CartController(CartServiceImpl cartService, AuthUtil authUtil, CartRepository cartRepo) {
		this.cartService = cartService;
		this.authUtil = authUtil;
		this.cartRepo = cartRepo;
	}


	@PostMapping("/cart/products/{productId}/quantity/{quantity}")
	public ResponseEntity<CartDTO> addProductToCart(@PathVariable Long productId,
			@PathVariable Integer quantity){
		CartDTO cartDTO = cartService.addProductToCart(productId,quantity);
		return new ResponseEntity<CartDTO>(cartDTO,HttpStatus.CREATED);
	}

	@GetMapping("/carts")
	public ResponseEntity<List<CartDTO>> getAllCarts(){
		List<CartDTO> carts = cartService.getAllCarts();
		return new ResponseEntity<List<CartDTO>>(carts,HttpStatus.FOUND);
	}
	
	@GetMapping("/carts/users/cart")
	public ResponseEntity<CartDTO> getCartById(){
		String emailId = authUtil.loggedInEmail();
		Cart cart = cartRepo.findCartByUser_UserEmail(emailId);
		Long cartId = cart.getCartId();
		CartDTO cartDTO = cartService.getCart(emailId,cartId);
		return new ResponseEntity<CartDTO>(cartDTO,HttpStatus.FOUND);
	}
	
	@PutMapping("/cart/products/{productId}/quantity/{operation}")
	public ResponseEntity<CartDTO> updateCartProduct(@PathVariable Long productId,
													 @PathVariable String operation){
		CartDTO cartDTO = cartService.updateProductQuantityInCart(productId,
				operation.equalsIgnoreCase("delete")?-1:1);
		return new ResponseEntity<CartDTO>(cartDTO,HttpStatus.OK);
	}
	
	@DeleteMapping("/carts/{cartId}/product/{productId}")
	public ResponseEntity<String> deleteProductFromCart(@PathVariable Long cartId,
			@PathVariable Long productId){
		String status = cartService.deleteProductFromCart(cartId, productId);
		return new ResponseEntity<String>(status,HttpStatus.OK);
	}

}
