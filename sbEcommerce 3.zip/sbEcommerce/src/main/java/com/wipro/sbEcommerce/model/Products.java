package com.wipro.sbEcommerce.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "product_tbl")
public class Products {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "product_id")
	private Long productId;
	
	@NotBlank
	@Size(min=5, message = "Product Name must contain atleast 5 character")
	private String productName;
	private String productImage;
	
	@NotBlank
	@Size(min=5, message = "Product Description must contain atleast 5 character")
	private String productDescription;
	private Integer productQuantity;
	private double productPrice;
	private double productDiscount;
	private double productSpecialPrice;
	
	@ManyToOne
	@JoinColumn(name = "category_id")
	private Category category;
	
	@ManyToOne
	@JoinColumn(name = "seller_id")
	private Users user;
	
	@OneToMany(mappedBy = "products",
			cascade = {CascadeType.MERGE,CascadeType.PERSIST,CascadeType.REMOVE},fetch = FetchType.EAGER)
	private List<CartItem>products = new ArrayList<>();

	public Products() {
		// TODO Auto-generated constructor stub
	}

	
	public Products(
			@NotBlank @Size(min = 5, message = "Product Name must contain atleast 5 character") String productName,
			String productImage,
			@NotBlank @Size(min = 5, message = "Product Description must contain atleast 5 character") String productDescription,
			Integer productQuantity, double productPrice, double productDiscount, double productSpecialPrice,
			Category category, Users user) {
		this.productName = productName;
		this.productImage = productImage;
		this.productDescription = productDescription;
		this.productQuantity = productQuantity;
		this.productPrice = productPrice;
		this.productDiscount = productDiscount;
		this.productSpecialPrice = productSpecialPrice;
		this.category = category;
		this.user = user;
		
	}




	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public Integer getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(Integer productQuantity) {
		this.productQuantity = productQuantity;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public double getProductSpecialPrice() {
		return productSpecialPrice;
	}

	public void setProductSpecialPrice(double productSpecialPrice) {
		this.productSpecialPrice = productSpecialPrice;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public String getProductImage() {
		return productImage;
	}

	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}

	public double getProductDiscount() {
		return productDiscount;
	}

	public void setProductDiscount(double productDiscount) {
		this.productDiscount = productDiscount;
	}


	public Users getUser() {
		return user;
	}


	public void setUser(Users user) {
		this.user = user;
	}


//	public List<CartItem> getProducts() {
//		return products;
//	}
//
//
//	public void setProducts(List<CartItem> products) {
//		this.products = products;
//	}
	
	
	

}
