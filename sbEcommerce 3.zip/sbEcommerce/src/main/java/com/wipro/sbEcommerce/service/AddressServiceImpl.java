package com.wipro.sbEcommerce.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.wipro.sbEcommerce.exceptions.ResourceNotFoundException;
import com.wipro.sbEcommerce.model.Addresses;
import com.wipro.sbEcommerce.model.Users;
import com.wipro.sbEcommerce.payload.AddressDTO;
import com.wipro.sbEcommerce.repository.AddressRepository;

import jakarta.validation.Valid;

@Service
public class AddressServiceImpl implements AddressService{
	private final ModelMapper modelMapper;
	private final AddressRepository addressRepo;
	
	

	
	public AddressServiceImpl(ModelMapper modelMapper, AddressRepository addressRepo) {
		this.modelMapper = modelMapper;
		this.addressRepo = addressRepo;
	}




	@Override
	public AddressDTO createAddress(@Valid AddressDTO addressDTO, Users user) {
		
		Addresses address = modelMapper.map(addressDTO, Addresses.class);
		address.setUser(user);
		List<Addresses> addressList = user.getAddresses();
		addressList.add(address);
		user.setAddresses(addressList);
		Addresses savedAddress = addressRepo.save(address);
		
		return modelMapper.map(savedAddress, AddressDTO.class);
	}

	@Override
	public List<AddressDTO> getAddresses() {
		List<Addresses> addresses = addressRepo.findAll();
		return addresses.stream().map(address->modelMapper.map(addresses, AddressDTO.class)).toList();
	}
	
	@Override
	public AddressDTO getAddressById(Long addressId) {
		Addresses address = addressRepo.findById(addressId).orElseThrow(()-> new ResourceNotFoundException("Addresses","addressId",addressId));
		return modelMapper.map(address, AddressDTO.class);
	}

}
