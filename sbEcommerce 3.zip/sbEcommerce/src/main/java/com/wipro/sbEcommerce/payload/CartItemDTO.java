package com.wipro.sbEcommerce.payload;

public class CartItemDTO {
	
	private Long cartItemID;
	private CartDTO cart;
	private ProductDTO product;
	private Integer quantity;
	private Double discount;
	private Double price;
	
	public CartItemDTO() {
		// TODO Auto-generated constructor stub
	}

	public CartItemDTO(CartDTO cart, ProductDTO product, Integer quantity, Double discount, Double price) {
		this.cart = cart;
		this.product = product;
		this.quantity = quantity;
		this.discount = discount;
		this.price = price;
	}

	public Long getCartItemID() {
		return cartItemID;
	}

	public void setCartItemID(Long cartItemID) {
		this.cartItemID = cartItemID;
	}

	public CartDTO getCart() {
		return cart;
	}

	public void setCart(CartDTO cart) {
		this.cart = cart;
	}

	public ProductDTO getProduct() {
		return product;
	}

	public void setProduct(ProductDTO product) {
		this.product = product;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Double getDiscount() {
		return discount;
	}

	public void setDiscount(Double discount) {
		this.discount = discount;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}
	
	
	

}
