package com.wipro.sbEcommerce.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;

@Table
@Entity(name = "order_tbl")
public class Order {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long orderId;
	
	@Email
	@Column(nullable = false)
	private String orderEmail;
	
	@OneToMany(mappedBy = "order", cascade = {CascadeType.PERSIST,CascadeType.MERGE})
	private List<OrderItems> orderItems = new ArrayList<>();
	
	private LocalDate orderDate;
	
	@OneToOne
	@JoinColumn(name = "payment_id")
	private Payment payment;
	
	private Double totalAmount;
	
	private String orderStatus;
	
	@ManyToOne
	@JoinColumn(name="address_id")
	private Addresses address;

	public Order() {
		// TODO Auto-generated constructor stub
	}

	

	public Order(Long orderId, @Email String orderEmail, List<OrderItems> orderItems, LocalDate orderDate,
			Payment payment, Double totalAmount, String orderStatus, Addresses address) {
		this.orderId = orderId;
		this.orderEmail = orderEmail;
		this.orderItems = orderItems;
		this.orderDate = orderDate;
		this.payment = payment;
		this.totalAmount = totalAmount;
		this.orderStatus = orderStatus;
		this.address = address;
	}



	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public String getOrderEmail() {
		return orderEmail;
	}

	public void setOrderEmail(String orderEmail) {
		this.orderEmail = orderEmail;
	}

	public List<OrderItems> getOrderItems() {
		return orderItems;
	}

	public void setOrderItems(List<OrderItems> orderItems) {
		this.orderItems = orderItems;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public Addresses getAddress() {
		return address;
	}

	public void setAddresses(Addresses address) {
		this.address = address;
	}



	public Payment getPayment() {
		return payment;
	}



	public void setPayment(Payment payment) {
		this.payment = payment;
	}



	public void setAddress(Addresses address) {
		this.address = address;
	}
	
	

}
