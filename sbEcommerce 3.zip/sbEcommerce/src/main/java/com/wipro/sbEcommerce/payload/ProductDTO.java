package com.wipro.sbEcommerce.payload;

public class ProductDTO {
	
	private Long productId;
	private String productName;
	private String productImage;
	private String productDescription;
	private Integer productQuantity;
	private double productPrice;
	private double productDiscount;
	private double productSpecialPrice;
	public ProductDTO() {
		// TODO Auto-generated constructor stub
	}
	public ProductDTO(Long productId, String productName, String productImage, String productDescription, Integer productQuantity,
			double productPrice, double productDiscount, double productSpecialPrice) {
		this.productId = productId;
		this.productName = productName;
		this.productImage = productImage;
		this.productDescription = productDescription;
		this.productQuantity = productQuantity;
		this.productPrice = productPrice;
		this.productDiscount = productDiscount;
		this.productSpecialPrice = productSpecialPrice;
	}
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductImage() {
		return productImage;
	}
	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}
	public Integer getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(Integer productQuantity) {
		this.productQuantity = productQuantity;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public double getProductDiscount() {
		return productDiscount;
	}
	public void setProductDiscount(double productDiscount) {
		this.productDiscount = productDiscount;
	}
	public double getProductSpecialPrice() {
		return productSpecialPrice;
	}
	public void setProductSpecialPrice(double productSpecialPrice) {
		this.productSpecialPrice = productSpecialPrice;
	}
	public String getproductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	
	

}
