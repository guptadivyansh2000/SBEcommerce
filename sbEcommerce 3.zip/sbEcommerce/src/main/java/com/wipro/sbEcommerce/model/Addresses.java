package com.wipro.sbEcommerce.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
public class Addresses {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long addressId;
	
	@NotBlank
	@Size(min = 7, message = "street name must be atleast 7 characters" )
	private String street;
	@NotBlank
	@Size(min = 7, message = "building name must be atleast 7 characters" )
	private String building;
	@NotBlank
	@Size(min = 4, message = "city name must be atleast 4 characters" )
	private String city;
	@NotBlank
	@Size(min = 2, message = "state name must be atleast 2 characters" )
	private String state;
	@NotBlank
	@Size(min = 2, message = "country name must be atleast 2 characters" )
	private String country;
	@NotBlank
	@Size(min = 6, message = "pincode name must be atleast 6 characters" )
	private String pincode;

	@ManyToOne
	@JoinColumn(name = "user_id")
	private Users user;
	
	

	public Addresses() {
		// TODO Auto-generated constructor stub
	}



	



	public Addresses(Long addressId,
			@NotBlank @Size(min = 7, message = "street name must be atleast 7 characters") String street,
			@NotBlank @Size(min = 7, message = "building name must be atleast 7 characters") String building,
			@NotBlank @Size(min = 4, message = "city name must be atleast 4 characters") String city,
			@NotBlank @Size(min = 2, message = "state name must be atleast 2 characters") String state,
			@NotBlank @Size(min = 2, message = "country name must be atleast 2 characters") String country,
			@NotBlank @Size(min = 6, message = "pincode name must be atleast 6 characters") String pincode,
			Users user) {
		this.addressId = addressId;
		this.street = street;
		this.building = building;
		this.city = city;
		this.state = state;
		this.country = country;
		this.pincode = pincode;
		this.user = user;
	}







	public Long getAddressId() {
		return addressId;
	}



	public void setAddressId(Long addressId) {
		this.addressId = addressId;
	}



	public String getStreet() {
		return street;
	}



	public void setStreet(String street) {
		this.street = street;
	}



	public String getBuilding() {
		return building;
	}



	public void setBuilding(String building) {
		this.building = building;
	}



	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}



	public String getState() {
		return state;
	}



	public void setState(String state) {
		this.state = state;
	}



	public String getCountry() {
		return country;
	}



	public void setCountry(String country) {
		this.country = country;
	}



	public String getPincode() {
		return pincode;
	}



	public void setPincode(String pincode) {
		this.pincode = pincode;
	}



	public Users getUser() {
		return user;
	}



	public void setUser(Users user) {
		this.user = user;
	}



	
	
	
	
}
