package com.wipro.sbEcommerce.service;

public interface OrderItemService {

}
