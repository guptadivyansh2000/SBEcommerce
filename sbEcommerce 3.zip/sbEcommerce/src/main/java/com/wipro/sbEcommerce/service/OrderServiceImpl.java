package com.wipro.sbEcommerce.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import com.wipro.sbEcommerce.exceptions.APIException;
import com.wipro.sbEcommerce.exceptions.ResourceNotFoundException;
import com.wipro.sbEcommerce.model.Addresses;
import com.wipro.sbEcommerce.model.Cart;
import com.wipro.sbEcommerce.model.CartItem;
import com.wipro.sbEcommerce.model.Order;
import com.wipro.sbEcommerce.model.OrderItems;
import com.wipro.sbEcommerce.model.Payment;
import com.wipro.sbEcommerce.model.Products;
import com.wipro.sbEcommerce.payload.OrderDTO;
import com.wipro.sbEcommerce.payload.OrderItemDTO;
import com.wipro.sbEcommerce.repository.AddressRepository;
import com.wipro.sbEcommerce.repository.CartRepository;
import com.wipro.sbEcommerce.repository.OrderItemRepository;
import com.wipro.sbEcommerce.repository.OrderRepository;
import com.wipro.sbEcommerce.repository.PaymentRepository;
import com.wipro.sbEcommerce.repository.ProductRepository;

import jakarta.transaction.Transactional;

public class OrderServiceImpl implements OrderService{
	
	private final CartRepository cartRepo;
	private final AddressRepository addressRepo;
	private final PaymentRepository paymentRepo;
	private final OrderRepository orderRepo;
	private final OrderItemRepository orderItemRepo;
	private final ProductRepository productRepo;
	private final CartService cartService;
	private final ModelMapper modelMapper;
	
	

	public OrderServiceImpl(CartRepository cartRepo, AddressRepository addressRepo, PaymentRepository paymentRepo,
			OrderRepository orderRepo, OrderItemRepository orderItemRepo, ProductRepository productRepo,
			CartService cartService, ModelMapper modelMapper) {
		this.cartRepo = cartRepo;
		this.addressRepo = addressRepo;
		this.paymentRepo = paymentRepo;
		this.orderRepo = orderRepo;
		this.orderItemRepo = orderItemRepo;
		this.productRepo = productRepo;
		this.cartService = cartService;
		this.modelMapper = modelMapper;
	}



	@Override
	@Transactional
	public OrderDTO placeOrder(String emailId, Long addressId, String paymentMethod, String pgName, String pgPaymentId,
			String pgStatus, String pgResponseMessage) {
		
		Cart cart = cartRepo.findCartByUser_UserEmail(emailId);
		
		if(cart==null) {
			throw new ResourceNotFoundException("Cart", "email", emailId);
			
		}
		
		Addresses address = addressRepo.findById(addressId).
				orElseThrow(()->new ResourceNotFoundException("Address", "addressId", addressId));
		
		Order order = new Order();
		
		order.setOrderEmail(emailId);
		order.setOrderDate(LocalDate.now());
		order.setTotalAmount(cart.getPrice());
		order.setOrderStatus("order accepted !!");
		order.setAddresses(address);
		
		Payment payment = new Payment(paymentMethod, pgPaymentId, pgStatus, pgResponseMessage, pgName);
		
		payment.setOrder(order);
		payment = paymentRepo.save(payment);
		order.setPayment(payment);
		Order saveOrder = orderRepo.save(order);
		
		List<CartItem> cartItems = cart.getCartItems();
		
		if(cartItems.isEmpty()) {
			throw new APIException("Cart is empty");
		}
		
		List<OrderItems> orderItems = new ArrayList<>();
		
		for(CartItem cartItem : cartItems) {
			OrderItems orderItem = new OrderItems();
			orderItem.setProduct(cartItem.getProducts());
			orderItem.setQuantity(cartItem.getQuantity());
			orderItem.setDiscount(cartItem.getDiscount());
			orderItem.setOrderedProductPrice(cartItem.getProductPrice());
			orderItem.setOrder(saveOrder);
			orderItems.add(orderItem);
		}
		
		orderItems = orderItemRepo.saveAll(orderItems);
		
		cart.getCartItems().forEach(item -> {
            int quantity = item.getQuantity();
            Products product = item.getProducts();

            // Reduce stock quantity
            product.setProductQuantity(product.getProductQuantity() - quantity);

            // Save product back to the database
            productRepo.save(product);

            // Remove items from cart
            cartService.deleteProductFromCart(cart.getCartId(), item.getProducts().getProductId());
        });
		OrderDTO orderDTO = modelMapper.map(saveOrder, OrderDTO.class);
		
		orderItems.forEach(item -> orderDTO.getOrderItems().add(modelMapper.map(item,OrderItemDTO.class)));
		
		orderDTO.setAddressId(addressId);
		
		return orderDTO;
	}

}
