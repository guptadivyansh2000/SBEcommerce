package com.wipro.sbEcommerce.payload;

public class OrderItemDTO {

	private Long orderItemId;
	private ProductDTO productDTO;
	private OrderDTO orderDTO;
	private Integer quantity;
	private double discount;
	private double orderedProductPrice;
	public OrderItemDTO() {
		// TODO Auto-generated constructor stub
	}
	public OrderItemDTO(Long orderItemId, ProductDTO productDTO, OrderDTO orderDTO, Integer quantity, double discount,
			double orderedProductPrice) {
		this.orderItemId = orderItemId;
		this.productDTO = productDTO;
		this.orderDTO = orderDTO;
		this.quantity = quantity;
		this.discount = discount;
		this.orderedProductPrice = orderedProductPrice;
	}
	public Long getOrderItemId() {
		return orderItemId;
	}
	public void setOrderItemId(Long orderItemId) {
		this.orderItemId = orderItemId;
	}
	public ProductDTO getProductDTO() {
		return productDTO;
	}
	public void setProductDTO(ProductDTO productDTO) {
		this.productDTO = productDTO;
	}
	public OrderDTO getOrderDTO() {
		return orderDTO;
	}
	public void setOrderDTO(OrderDTO orderDTO) {
		this.orderDTO = orderDTO;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public double getOrderedProductPrice() {
		return orderedProductPrice;
	}
	public void setOrderedProductPrice(double orderedProductPrice) {
		this.orderedProductPrice = orderedProductPrice;
	}
	
	
}
