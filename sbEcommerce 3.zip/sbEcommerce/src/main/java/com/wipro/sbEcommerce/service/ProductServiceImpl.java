package com.wipro.sbEcommerce.service;

import java.io.IOException;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.wipro.sbEcommerce.exceptions.APIException;
import com.wipro.sbEcommerce.exceptions.ResourceNotFoundException;
import com.wipro.sbEcommerce.model.Category;
import com.wipro.sbEcommerce.model.Products;
import com.wipro.sbEcommerce.payload.ProductDTO;
import com.wipro.sbEcommerce.payload.ProductResponse;
import com.wipro.sbEcommerce.repository.CategoryRepository;
import com.wipro.sbEcommerce.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
	private ProductRepository productRepo;
	
	@Autowired
	private CategoryRepository categoryRepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private FileService fileService;
	
	@Value("{project.image}")
	private String path;
	
	@Override
	public ProductDTO addProduct(ProductDTO productDTO, Long categoryId) {
		Category category = categoryRepo.findById(categoryId)
				.orElseThrow(()->
				new ResourceNotFoundException("Category", "categoryId", categoryId));
		boolean isProductNotPresent = true;
		List<Products> products = category.getProduct();
		for(Products product : products) {
			if(product.getProductName().equals(productDTO.getProductName())) {
				isProductNotPresent = false;
				break;
			}
		}
		if(isProductNotPresent) {
			Products product = modelMapper.map(productDTO, Products.class);
			product.setProductImage("default.png");
			product.setCategory(category);
			double specialPrice = product.getProductPrice()-((product.getProductDiscount()*0.01)*product.getProductPrice());
			product.setProductSpecialPrice(specialPrice);
			Products savedProduct = productRepo.save(product);
			return modelMapper.map(savedProduct, ProductDTO.class);
		}
		
		else {
			throw new APIException("Product is already exists");
		}
		
	}



	@Override
	public ProductResponse getAllProducts(Integer pageNumber, Integer pageSize, String sortBy, String sortOrder) {
		
		Sort sortByAndOrder = sortOrder.equalsIgnoreCase("asc")
				? Sort.by(sortBy).ascending()
				: Sort.by(sortBy).descending();
		
		Pageable pageDetails = PageRequest.of(pageNumber, pageSize, sortByAndOrder);
		Page<Products> pageProducts = productRepo.findAll(pageDetails);
		
		List<Products> products = pageProducts.getContent();
		
		List<ProductDTO> productDTOS = products.stream()
				.map(product->modelMapper.map(product, ProductDTO.class))
				.toList();
		
		ProductResponse productResponse = new ProductResponse();
		productResponse.setContent(productDTOS);
		productResponse.setPageNumber(pageProducts.getNumber());
		productResponse.setPageSize(pageProducts.getSize());
		productResponse.setTotalElements(pageProducts.getTotalElements());
		productResponse.setTotalPages(pageProducts.getTotalPages());
		productResponse.setLastPage(pageProducts.isLast());
		return productResponse;
	}



	@Override
	public ProductResponse getProductsByCategory(Long categoryId, Integer pageNumber, Integer pageSize, String sortBy, String sortOrder) {
		
		Category category = categoryRepo.findById(categoryId)
				.orElseThrow(()->new ResourceNotFoundException("Category","categoryId",categoryId));
		
		Sort sortByAndOrder = sortOrder.equalsIgnoreCase("asc")
				? Sort.by(sortBy).ascending()
				: Sort.by(sortBy).descending();
		
		Pageable pageDetails = PageRequest.of(pageNumber, pageSize, sortByAndOrder);
		Page<Products> pageProducts = productRepo.findByCategoryOrderByProductPriceAsc(category, pageDetails);
		
		
		
		
		List<ProductDTO> productDTOS = pageProducts.stream().map(product->modelMapper.map(product, ProductDTO.class)).toList();
		ProductResponse productResponse = new ProductResponse();
		productResponse.setContent(productDTOS);
		productResponse.setPageNumber(pageProducts.getNumber());
		productResponse.setPageSize(pageProducts.getSize());
		productResponse.setTotalElements(pageProducts.getTotalElements());
		productResponse.setTotalPages(pageProducts.getTotalPages());
		productResponse.setLastPage(pageProducts.isLast());
		return productResponse;
	}



	@Override
	public ProductResponse getProductByKeyword(String keyword, Integer pageNumber, Integer pageSize, String sortBy, String sortOrder) {
		
		Sort sortByAndOrder = sortOrder.equalsIgnoreCase("asc")
				? Sort.by(sortBy).ascending()
				: Sort.by(sortBy).descending();
		Pageable pageDetails = PageRequest.of(pageNumber, pageSize, sortByAndOrder);
		Page<Products> pageProducts = productRepo.findByProductNameLikeIgnoreCase("%"+keyword+"%",pageDetails);
		
		List<Products> products = pageProducts.getContent();
		
		List<ProductDTO> productDTOS = products.stream().map(product->modelMapper.map(product, ProductDTO.class)).toList();
		
		
		ProductResponse productResponse = new ProductResponse();
		productResponse.setContent(productDTOS);
		productResponse.setPageNumber(pageProducts.getNumber());
		productResponse.setPageSize(pageProducts.getSize());
		productResponse.setTotalElements(pageProducts.getTotalElements());
		productResponse.setTotalPages(pageProducts.getTotalPages());
		productResponse.setLastPage(pageProducts.isLast());
		return productResponse;
	}



	@Override
	public ProductDTO updateProduct(ProductDTO productDTO, Long productId) {
		Products productFromDB = productRepo.findById(productId).orElseThrow(()->new ResourceNotFoundException("Products","productId",productId));
		Products product = modelMapper.map(productDTO, Products.class);
		productFromDB.setProductName(product.getProductName());
		productFromDB.setProductDescription(product.getProductDescription());
		productFromDB.setProductQuantity(product.getProductQuantity());
		productFromDB.setProductPrice(product.getProductPrice());
		productFromDB.setProductDiscount(product.getProductDiscount());
		double specialPrice = product.getProductPrice()-((product.getProductDiscount()*0.01)*product.getProductPrice());
		productFromDB.setProductSpecialPrice(specialPrice);
		Products savedProduct = productRepo.save(productFromDB);
		return modelMapper.map(savedProduct, ProductDTO.class);
		
	}



	@Override
	public ProductDTO deleteProduct(Long productId) {
		Products product = productRepo.findById(productId).orElseThrow(()->new ResourceNotFoundException("Products","productId",productId));
		productRepo.delete(product);
		return modelMapper.map(product, ProductDTO.class);
	}



	@Override
	public ProductDTO updateProductImage(Long productId, MultipartFile image) throws IOException {
		//Get the product from db
		Products productFromDB = productRepo.findById(productId).orElseThrow(()->new ResourceNotFoundException("Products","productsId",productId));
		//update image
		
		String fileName = fileService.uploadImage(path, image);
		//set the productimage
		productFromDB.setProductImage(fileName);
		//save into db
		Products updatedProduct = productRepo.save(productFromDB);
		//return dto after mapping product dto
		return modelMapper.map(updatedProduct, ProductDTO.class);
	}



	

}
