package com.wipro.sbEcommerce.payload;

import java.util.ArrayList;
import java.util.List;

public class CartDTO {
	
	
	private Long cartId;
	
	private Double price = 0.0;
	
	private List<ProductDTO> products = new ArrayList<>();

	public CartDTO() {
		// TODO Auto-generated constructor stub
	}

	public CartDTO(Double price, List<ProductDTO> products) {
		
		this.price = price;
		this.products = products;
	}

	public Long getCartId() {
		return cartId;
	}

	public void setCartId(Long cartId) {
		this.cartId = cartId;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public List<ProductDTO> getProducts() {
		return products;
	}

	public void setProducts(List<ProductDTO> products) {
		this.products = products;
	}
	
	

}
