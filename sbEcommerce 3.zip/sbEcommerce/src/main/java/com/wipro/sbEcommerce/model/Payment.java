package com.wipro.sbEcommerce.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Table
@Entity(name = "payment_tbl")
public class Payment {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long paymentId;
	
	@OneToOne(mappedBy = "payment", cascade = {CascadeType.PERSIST,CascadeType.MERGE})
	private Order order;
	
	@NotBlank
	@Size(min = 4, message = "method should contains at least 4 characters")
	private String paymentMethod;
	
	private String pgPaymentId;
	private String pgStatus;
	private String pgResponseMessage;
	private String pgName;
	public Payment() {
		// TODO Auto-generated constructor stub
	}

	

	public Payment(@NotBlank @Size(min = 4, message = "method should contains at least 4 characters") String paymentMethod,
			String pgPaymentId, String pgStatus, String pgResponseMessage, String pgName) {
		
		this.paymentMethod = paymentMethod;
		this.pgPaymentId = pgPaymentId;
		this.pgStatus = pgStatus;
		this.pgResponseMessage = pgResponseMessage;
		this.pgName = pgName;
	}



	public Long getPaymentId() {
		return paymentId;
	}



	public void setPaymentId(Long paymentId) {
		this.paymentId = paymentId;
	}



	public Order getOrder() {
		return order;
	}



	public void setOrder(Order order) {
		this.order = order;
	}



	public String getPaymentMethod() {
		return paymentMethod;
	}



	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}



	public String getPgPaymentId() {
		return pgPaymentId;
	}



	public void setPgPaymentId(String pgPaymentId) {
		this.pgPaymentId = pgPaymentId;
	}



	public String getPgStatus() {
		return pgStatus;
	}



	public void setPgStatus(String pgStatus) {
		this.pgStatus = pgStatus;
	}



	public String getPgResponseMessage() {
		return pgResponseMessage;
	}



	public void setPgResponseMessage(String pgResponseMessage) {
		this.pgResponseMessage = pgResponseMessage;
	}



	public String getPgName() {
		return pgName;
	}



	public void setPgName(String pgName) {
		this.pgName = pgName;
	}






	
	
	

}
