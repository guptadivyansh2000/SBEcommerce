package com.wipro.sbEcommerce.service;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.wipro.sbEcommerce.exceptions.APIException;
import com.wipro.sbEcommerce.exceptions.ResourceNotFoundException;
import com.wipro.sbEcommerce.model.Cart;
import com.wipro.sbEcommerce.model.CartItem;
import com.wipro.sbEcommerce.model.Products;
import com.wipro.sbEcommerce.payload.CartDTO;
import com.wipro.sbEcommerce.payload.ProductDTO;
import com.wipro.sbEcommerce.repository.CartItemRepository;
import com.wipro.sbEcommerce.repository.CartRepository;
import com.wipro.sbEcommerce.repository.ProductRepository;
import com.wipro.sbEcommerce.util.AuthUtil;

import jakarta.transaction.Transactional;

@Service
public class CartServiceImpl implements CartService {
	
	private final CartRepository cartRepo;
	private final AuthUtil authUtil;
	private final ProductRepository productRepo;
	private final CartItemRepository cartItemRepo;
	private final ModelMapper modelMapper;
	
	


	public CartServiceImpl(CartRepository cartRepo, AuthUtil authUtil, ProductRepository productRepo,
			CartItemRepository cartItemRepo, ModelMapper modelMapper) {
		this.cartRepo = cartRepo;
		this.authUtil = authUtil;
		this.productRepo = productRepo;
		this.cartItemRepo = cartItemRepo;
		this.modelMapper = modelMapper;
	}


	@Override
	public CartDTO addProductToCart(Long productId, Integer quantity) {
		Cart cart = createCart();
		
		Products product = productRepo.findById(productId)
				.orElseThrow(() -> new ResourceNotFoundException("Products","productId",productId));
		
		CartItem cartItem = cartItemRepo.findCartItemByProducts_ProductIdAndCart_CartId(cart.getCartId(),productId);
		
		if(cartItem!=null) {
			throw new APIException("Products "+product.getProductName()+" already exists in the cart");
		}
		
		if(product.getProductQuantity()==0) {
			throw new APIException(product.getProductName()+" is not available");
		}
		
		if(product.getProductQuantity()<quantity) {
			throw new APIException("please make an order of the "+product.getProductName()+" less than or equal to the quantity "+product.getProductQuantity()+".");
		}
		
		
		CartItem newCartItem = new CartItem();
		
		newCartItem.setProduct(product);
		newCartItem.setCart(cart);
		newCartItem.setQuantity(quantity);
		newCartItem.setDiscount(product.getProductDiscount());
		newCartItem.setProductPrice(product.getProductPrice());
		
		cartItemRepo.save(newCartItem);
		
		product.setProductQuantity(product.getProductQuantity());
		
		cart.setPrice(cart.getPrice()+(product.getProductSpecialPrice()*quantity));
		
		cartRepo.save(cart);
		
		CartDTO cartDTO = modelMapper.map(cart,CartDTO.class);
		List<CartItem> cartItems = cart.getCartItems();
		
		Stream<ProductDTO> productStream = cartItems.stream().map(item->{
			ProductDTO map = modelMapper.map(item.getProducts(), ProductDTO.class);
			map.setProductQuantity(item.getQuantity());
			return map;
		});
		 cartDTO.setProducts(productStream.toList());

		return cartDTO;
	}
	
	
	private Cart createCart() {
		
		Cart userCart = cartRepo.findCartByUser_UserEmail(authUtil.loggedInEmail());
		if(userCart!=null) {
			return userCart;
		}
		
		Cart cart = new Cart();
		cart.setPrice(0.0);
		cart.setUser(authUtil.loggedInUser());
		Cart newCart = cartRepo.save(cart);
		
		return newCart;
	}

	@Override
	public List<CartDTO> getAllCarts() {
		List<Cart> carts = cartRepo.findAll();
		
		if(carts.size()==0) {
			throw new APIException("cart is not exists");
		}
		
		List<CartDTO> cartDTOs = carts.stream().map(cart->{
			CartDTO cartDTO = modelMapper.map(cart, CartDTO.class);
			
			List<ProductDTO> products = cart.getCartItems().stream().map(cartItem ->{
				ProductDTO productDTO = modelMapper.map(cartItem.getProducts(), ProductDTO.class);
				productDTO.setProductQuantity(cartItem.getQuantity());
				return productDTO;
			}).toList();
			
			cartDTO.setProducts(products);
			return cartDTO;
		}).collect(Collectors.toList());
		return cartDTOs;
	}

	@Override
	public CartDTO getCart(String emailId, Long cartId) {
		Cart cart = cartRepo.findCartByUser_UserEmailAndCartId(emailId,cartId);
		if(cart==null) {
			throw new ResourceNotFoundException("Cart","cartId",cartId);
		}
		CartDTO cartDTO = modelMapper.map(cart, CartDTO.class);
		cart.getCartItems().forEach(c->c.getQuantity());
		List<ProductDTO> products = cart.getCartItems().stream()
				.map(p->modelMapper.map(p.getProducts(), ProductDTO.class))
				.toList();
		cartDTO.setProducts(products);
		return cartDTO;
	}
	
	
	@Transactional
	@Override
	public CartDTO updateProductQuantityInCart(Long productId, Integer productQuantity) {
		
		String emailId = authUtil.loggedInEmail();
		Cart userCart = cartRepo.findCartByUser_UserEmail(emailId);
		Long cartId = userCart.getCartId();
		
		Cart cart = cartRepo.findById(cartId)
				.orElseThrow(()-> new ResourceNotFoundException("Cart","cartId",cartId));
		
		Products product = productRepo.findById(productId)
				.orElseThrow(()-> new ResourceNotFoundException("Products","productId",productId));
		
		if(product.getProductQuantity()==0) {
			throw new APIException(product.getProductName()+" is not available");
		}
		
		if(product.getProductQuantity()>productQuantity) {
			throw new APIException("Please, make an order of the " + product.getProductName()
            + " less than or equal to the quantity " + product.getProductQuantity() + ".");
		}
		
		CartItem cartItem = cartItemRepo.findCartItemByProducts_ProductIdAndCart_CartId(productId, cartId);
		
		if(cartItem == null) {
			throw new APIException("Product " + product.getProductName() + " not available in the cart!!!");
		}
		
		int netQuantity = cartItem.getQuantity()+productQuantity;
		
		if(netQuantity<0) {
			throw new APIException("The resulting quantity cannot be negative.");
		}
		
		if(netQuantity==0) {
			deleteProductFromCart(cartId,productId);
		}
		else {
			cartItem.setProductPrice(product.getProductPrice());
			cartItem.setQuantity(cartItem.getQuantity());
			cartItem.setDiscount(product.getProductDiscount());
			cart.setPrice(cart.getPrice()+(cartItem.getProductPrice()*productQuantity));
			cartRepo.save(cart);
		}
		
		CartDTO cartDTO = modelMapper.map(cart, CartDTO.class);
		
		List<CartItem> cartItems = cart.getCartItems();
		
		Stream<ProductDTO> productStream = cartItems.stream().map(item->{
			ProductDTO prd = modelMapper.map(item.getProducts(),ProductDTO.class);
			prd.setProductQuantity(item.getQuantity());
			return prd;
		});
		
		cartDTO.setProducts(productStream.toList());
		return cartDTO;
	}


	@Transactional
	@Override
	public String deleteProductFromCart(Long cartId, Long productId) {
		Cart cart = cartRepo.findById(cartId)
				.orElseThrow(()->new ResourceNotFoundException("Cart", "cartId", cartId));
		
		CartItem cartItem = cartItemRepo.findCartItemByProducts_ProductIdAndCart_CartId(productId, cartId);
		
		if (cartItem == null) {
            throw new ResourceNotFoundException("Product", "productId", productId);
        }
		cart.setPrice(cart.getPrice() -
                (cartItem.getProductPrice() * cartItem.getQuantity()));

        cartItemRepo.deleteByCart_CartIdAndProducts_ProductId(cartId, productId);

        return "Product " + cartItem.getProducts().getProductName() + " removed from the cart !!!";
		
		
	}
	
	@Override
	public void updateProductInCarts(Long cartId, Long productId) {
		Cart cart = cartRepo.findById(cartId)
				.orElseThrow(()->new ResourceNotFoundException("Cart","cartId",cartId));
		
		Products product = productRepo.findById(productId)
				.orElseThrow(()->new ResourceNotFoundException("Products","productId",productId));
		
		CartItem cartItem = cartItemRepo.findCartItemByProducts_ProductIdAndCart_CartId(cartId, productId);
		
		if (cartItem == null) {
            throw new APIException("Product " + product.getProductName() + " not available in the cart!!!");
        }
		
		double cartPrice = cart.getPrice()-(cartItem.getProductPrice()*cartItem.getQuantity());
		
		cartItem.setProductPrice(product.getProductSpecialPrice());
		
		cart.setPrice(cartPrice+(cartItem.getProductPrice()*cartItem.getQuantity()));
		
		cartItem = cartItemRepo.save(cartItem);
	}

}
