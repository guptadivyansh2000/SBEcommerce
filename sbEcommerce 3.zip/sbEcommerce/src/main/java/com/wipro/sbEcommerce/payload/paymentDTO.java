package com.wipro.sbEcommerce.payload;

public class paymentDTO {
	
	private Long paymentId;
	private OrderDTO orderDTO;
	private String paymentMethod;
	private String pgPaymentId;
	private String pgStatus;
	private String pgResponseMessage;
	public paymentDTO() {
		// TODO Auto-generated constructor stub
	}
	public paymentDTO(Long paymentId, OrderDTO orderDTO, String paymentMethod, String pgPaymentId, String pgStatus,
			String pgResponseMessage) {
		this.paymentId = paymentId;
		this.orderDTO = orderDTO;
		this.paymentMethod = paymentMethod;
		this.pgPaymentId = pgPaymentId;
		this.pgStatus = pgStatus;
		this.pgResponseMessage = pgResponseMessage;
	}
	public Long getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(Long paymentId) {
		this.paymentId = paymentId;
	}
	public OrderDTO getOrderDTO() {
		return orderDTO;
	}
	public void setOrderDTO(OrderDTO orderDTO) {
		this.orderDTO = orderDTO;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public String getPgPaymentId() {
		return pgPaymentId;
	}
	public void setPgPaymentId(String pgPaymentId) {
		this.pgPaymentId = pgPaymentId;
	}
	public String getPgStatus() {
		return pgStatus;
	}
	public void setPgStatus(String pgStatus) {
		this.pgStatus = pgStatus;
	}
	public String getPgResponseMessage() {
		return pgResponseMessage;
	}
	public void setPgResponseMessage(String pgResponseMessage) {
		this.pgResponseMessage = pgResponseMessage;
	}
	
	
}
