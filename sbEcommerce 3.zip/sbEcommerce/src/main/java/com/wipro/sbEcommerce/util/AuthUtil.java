package com.wipro.sbEcommerce.util;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.wipro.sbEcommerce.model.Users;
import com.wipro.sbEcommerce.repository.UserRepository;

@Component
public class AuthUtil {
	
	private final UserRepository userRepo;
	
	
	public AuthUtil(UserRepository userRepo) {
		this.userRepo = userRepo;
	}

	public String loggedInEmail() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Users user = userRepo.findByUserName(authentication.getName())
				.orElseThrow(()-> new UsernameNotFoundException("user not found "+authentication.getName()));
		
		return user.getUserEmail();
		
	}
	
	public Users loggedInUser() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Users user = userRepo.findByUserName(authentication.getName())
				.orElseThrow(()-> new UsernameNotFoundException("user not found"));
		
		return user;
		
	}
	

}
