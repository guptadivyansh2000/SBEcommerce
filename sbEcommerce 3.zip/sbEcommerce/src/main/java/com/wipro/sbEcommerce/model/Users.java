package com.wipro.sbEcommerce.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "user_tbl",
		uniqueConstraints = {
				@UniqueConstraint(columnNames = "user_name"),
				@UniqueConstraint(columnNames = "user_email")
		}
		)

public class Users {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long userId;
	
	@NotBlank
	@Size(max = 20)
	@Column(name = "user_name")
	private String userName;
	
	@NotBlank
	@Size(max = 50)
	@Email
	@Column(name = "user_email")
	private String userEmail;
	
	@NotBlank
	@Size(max = 120)
	@Column(name = "user_password")
	private String userPassword;
	
	
	@ManyToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE},
			fetch = FetchType.EAGER)
	@JoinTable(name = "user_role",
				joinColumns = @JoinColumn(name = "user_id"),
				inverseJoinColumns = @JoinColumn(name = "role_id"))
	private Set<Role> role = new HashSet<>();
	
	@OneToMany(mappedBy = "user",cascade = {CascadeType.PERSIST,CascadeType.MERGE},orphanRemoval = true)
//	@JoinTable(name = "user_addresses",
//	joinColumns = @JoinColumn(name = "user_id"),
//	inverseJoinColumns = @JoinColumn(name = "addresses_id"))
	private List<Addresses> addresses = new ArrayList<>();
	
	
	@OneToOne(mappedBy = "user", cascade = {CascadeType.PERSIST,CascadeType.MERGE},orphanRemoval = true)
	private Cart cart;
	
	@OneToMany(mappedBy = "user",
			cascade = {
					CascadeType.PERSIST,
					CascadeType.MERGE
			},
			orphanRemoval = true)
	private Set<Products> products;

	public Users() {
		// TODO Auto-generated constructor stub
	}


	public Users(@NotBlank @Size(max = 20) String userName, @NotBlank @Size(max = 50) @Email String userEmail,
			@NotBlank @Size(max = 120) String userPassword, Set<Role> role, List<Addresses> addresses,
			Set<Products> products, Cart cart) {
		this.userName = userName;
		this.userEmail = userEmail;
		this.userPassword = userPassword;
		this.role = role;
		this.addresses = addresses;
		this.cart = cart;
		this.products = products;
	}










	public Users(Long userId, @NotBlank @Size(max = 20) String userName,
			@NotBlank @Size(max = 20) @Email String userEmail, @NotBlank @Size(max = 20) String userPassword,
			Set<Role> role, List<Addresses> addresses, Set<Products> products) {
		this.userId = userId;
		this.userName = userName;
		this.userEmail = userEmail;
		this.userPassword = userPassword;
		this.role = role;
		this.addresses = addresses;
		this.products = products;
	}



	public Users(String username2, String email, String encode) {
		// TODO Auto-generated constructor stub
	}


	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public Set<Role> getRole() {
		return role;
	}

	public void setRoles(Set<Role> role) {
		this.role = role;
	}



	public List<Addresses> getAddresses() {
		return addresses;
	}



	public void setAddresses(List<Addresses> addresses) {
		this.addresses = addresses;
	}



	public Set<Products> getProducts() {
		return products;
	}



	public void setProducts(Set<Products> products) {
		this.products = products;
	}



	public void setRole(Set<Role> role) {
		this.role = role;
	}


	public Cart getCart() {
		return cart;
	}

	public void setCart(Cart cart) {
		this.cart = cart;
	}
	
	
}
