package com.wipro.sbEcommerce.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.sbEcommerce.payload.OrderDTO;
import com.wipro.sbEcommerce.payload.OrderRequestDTO;
import com.wipro.sbEcommerce.service.OrderService;
import com.wipro.sbEcommerce.util.AuthUtil;

@RestController
@RequestMapping("/api")
public class OrderController {
	
	private final OrderService orderService;
	private final AuthUtil authUtil;
	
	
	public OrderController(OrderService orderService, AuthUtil authUtil) {
		this.orderService = orderService;
		this.authUtil = authUtil;
	}
	
	@PostMapping("/order/users/payments/{paymentMethod}")
	public ResponseEntity<OrderDTO> orderProducts(@PathVariable String paymentMethod, @RequestBody OrderRequestDTO orderRequestDTO){
		
		String emailId = authUtil.loggedInEmail();
		OrderDTO order = orderService.placeOrder(emailId, 
				orderRequestDTO.getAddressId(),
				paymentMethod,
				orderRequestDTO.getPgName(),
				orderRequestDTO.getPgPaymentId(),
				orderRequestDTO.getPgStatus(),
				orderRequestDTO.getPgResponseMessage());
		
		return new ResponseEntity<>(order,HttpStatus.CREATED);
		
		
	}
	

}
