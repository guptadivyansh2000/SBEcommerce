package com.wipro.sbEcommerce.service;

import java.util.List;

import com.wipro.sbEcommerce.model.Users;
import com.wipro.sbEcommerce.payload.AddressDTO;

import jakarta.validation.Valid;

public interface AddressService {

	AddressDTO createAddress(@Valid AddressDTO addressDTO, Users user);

	List<AddressDTO> getAddresses();

	AddressDTO getAddressById(Long addressId);

}
