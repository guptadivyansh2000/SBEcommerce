import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ElevatorProblem {
        private static final int TOTAL_FLOORS = 6; // G + N (0-5 floors)
        private static final int MAX_PASSENGERS = 5;

        // Elevator Class
        private static class Elevator {
            private int currentFloor = 0; // Ground Floor
            private boolean isMoving = false;
            private List<Passenger> passengers = new ArrayList<>();

            // Synchronize the method to move elevator
            public synchronized void moveToFloor(int targetFloor) {
                System.out.printf("[Elevator Thread] Elevator moves to Floor: %d%n", targetFloor);
                this.currentFloor = targetFloor;
                this.isMoving = false;
            }

            // Check if floor is valid for direction
            public boolean isValidFloor(int floor, String direction) {
                if (floor < 0 || floor >= TOTAL_FLOORS) return false;

                if (floor == 0 && direction.equals("up")) return true;
                if (floor == 5 && direction.equals("down")) return true;

                return true;
            }

            // Add passenger to elevator
            public synchronized void addPassenger(Passenger passenger) {
                if (passengers.size() < MAX_PASSENGERS) {
                    passengers.add(passenger);
                }
            }
        }

        // Passenger Class
        private static class Passenger extends Thread {
            private int outsideFloor;
            private int destinationFloor;
            private String direction;
            private Elevator elevator;

            public Passenger(Elevator elevator, int outsideFloor, String direction) {
                this.elevator = elevator;
                this.outsideFloor = outsideFloor;
                this.direction = direction;

                // Randomly generate destination floor
                Random random = new Random();
                do {
                    this.destinationFloor = random.nextInt(TOTAL_FLOORS);
                } while (this.destinationFloor == this.outsideFloor);
            }

            @Override
            public void run() {
                // Simulate passenger behavior
                synchronized (elevator) {
                    System.out.printf("[Passenger-Thread] Input Outside Floor: %d, direction: %s%n",
                            outsideFloor, direction);

                    // Check if floor is valid
                    if (elevator.isValidFloor(outsideFloor, direction)) {
                        elevator.addPassenger(this);

                        System.out.printf("[Passenger-Thread] Input Inside Elevator to Floor: %d%n",
                                destinationFloor);

                        // Move elevator
                        elevator.moveToFloor(destinationFloor);

                        System.out.printf("[Passenger-Thread] Passenger Moved out at Floor: %d%n",
                                destinationFloor);
                    }
                }
            }
        }

        public static void main(String[] args) {
            // Create elevator
            Elevator elevator = new Elevator();

            // Create thread pool
            ExecutorService executorService = Executors.newFixedThreadPool(10);

            // Simulate multiple passengers
            Random random = new Random();
            for (int i = 0; i < 5; i++) {
                int outsideFloor = random.nextInt(TOTAL_FLOORS);
                String direction = outsideFloor == 0 ? "up" :
                        outsideFloor == 5 ? "down" :
                                random.nextBoolean() ? "up" : "down";

                Passenger passenger = new Passenger(elevator, outsideFloor, direction);
                executorService.submit(passenger);
            }

            // Shutdown thread pool
            executorService.shutdown();
        }
    }
